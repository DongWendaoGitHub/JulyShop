create view ztv_dayeffort as
select round(sum(`zentaoep`.`zt_effort`.`consumed`), 1) AS `consumed`, `zentaoep`.`zt_effort`.`date` AS `date`
from `zentaoep`.`zt_effort`
group by `zentaoep`.`zt_effort`.`date`;

