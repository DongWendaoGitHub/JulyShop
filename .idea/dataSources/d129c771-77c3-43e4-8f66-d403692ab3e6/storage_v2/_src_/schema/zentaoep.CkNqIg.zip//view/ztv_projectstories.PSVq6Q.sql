create view ztv_projectstories as
select `t1`.`project` AS `project`, count('*') AS `stories`, sum(if((`t2`.`status` = 'closed'), 0, 1)) AS `undone`
from (`zentaoep`.`zt_projectstory` `t1`
         left join `zentaoep`.`zt_story` `t2` on ((`t1`.`story` = `t2`.`id`)))
where (`t2`.`deleted` = '0')
group by `t1`.`project`;

