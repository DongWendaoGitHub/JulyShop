create view ztv_productbugs as
select `zentaoep`.`zt_bug`.`product`                          AS `product`,
       count(0)                                               AS `bugs`,
       sum(if((`zentaoep`.`zt_bug`.`resolution` = ''), 0, 1)) AS `resolutions`,
       sum(if((`zentaoep`.`zt_bug`.`severity` <= 2), 1, 0))   AS `seriousBugs`
from `zentaoep`.`zt_bug`
where (`zentaoep`.`zt_bug`.`deleted` = '0')
group by `zentaoep`.`zt_bug`.`product`;

