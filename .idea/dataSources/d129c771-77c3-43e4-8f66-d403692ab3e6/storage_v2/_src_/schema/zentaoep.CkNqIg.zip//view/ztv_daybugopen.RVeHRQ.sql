create view ztv_daybugopen as
select count(0) AS `bugopen`, left(`zentaoep`.`zt_action`.`date`, 10) AS `day`
from `zentaoep`.`zt_action`
where ((`zentaoep`.`zt_action`.`objectType` = 'bug') and (`zentaoep`.`zt_action`.`action` = 'opened'))
group by left(`zentaoep`.`zt_action`.`date`, 10);

