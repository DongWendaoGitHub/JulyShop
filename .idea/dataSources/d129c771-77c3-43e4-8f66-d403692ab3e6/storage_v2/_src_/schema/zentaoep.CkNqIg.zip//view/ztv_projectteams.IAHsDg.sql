create view ztv_projectteams as
select `zentaoep`.`zt_team`.`root` AS `project`, count('*') AS `teams`
from `zentaoep`.`zt_team`
where (`zentaoep`.`zt_team`.`type` = 'project')
group by `zentaoep`.`zt_team`.`root`;

