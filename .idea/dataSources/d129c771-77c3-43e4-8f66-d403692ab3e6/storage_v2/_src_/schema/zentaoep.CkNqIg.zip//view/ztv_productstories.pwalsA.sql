create view ztv_productstories as
select `zentaoep`.`zt_story`.`product`                            AS `product`,
       count('*')                                                 AS `stories`,
       sum(if((`zentaoep`.`zt_story`.`status` = 'closed'), 0, 1)) AS `undone`
from `zentaoep`.`zt_story`
where (`zentaoep`.`zt_story`.`deleted` = '0')
group by `zentaoep`.`zt_story`.`product`;

