create view ztv_daytaskfinish as
select count(0) AS `taskfinish`, left(`zentaoep`.`zt_action`.`date`, 10) AS `day`
from `zentaoep`.`zt_action`
where ((`zentaoep`.`zt_action`.`objectType` = 'task') and (`zentaoep`.`zt_action`.`action` = 'finished'))
group by left(`zentaoep`.`zt_action`.`date`, 10);

