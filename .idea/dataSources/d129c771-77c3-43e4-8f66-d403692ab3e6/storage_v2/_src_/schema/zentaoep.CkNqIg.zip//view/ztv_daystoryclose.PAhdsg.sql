create view ztv_daystoryclose as
select count(0) AS `storyclose`, left(`zentaoep`.`zt_action`.`date`, 10) AS `day`
from `zentaoep`.`zt_action`
where ((`zentaoep`.`zt_action`.`objectType` = 'story') and (`zentaoep`.`zt_action`.`action` = 'closed'))
group by left(`zentaoep`.`zt_action`.`date`, 10);

