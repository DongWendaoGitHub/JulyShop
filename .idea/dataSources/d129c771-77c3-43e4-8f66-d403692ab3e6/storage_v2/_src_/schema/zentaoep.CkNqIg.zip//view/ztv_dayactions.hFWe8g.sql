create view ztv_dayactions as
select count(0) AS `actions`, left(`zentaoep`.`zt_action`.`date`, 10) AS `day`
from `zentaoep`.`zt_action`
group by left(`zentaoep`.`zt_action`.`date`, 10);

