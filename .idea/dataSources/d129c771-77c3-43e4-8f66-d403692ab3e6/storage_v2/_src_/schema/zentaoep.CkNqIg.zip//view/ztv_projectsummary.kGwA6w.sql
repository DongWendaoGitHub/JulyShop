create view ztv_projectsummary as
select `zentaoep`.`zt_task`.`project` AS                                                      `project`,
       sum(if((`zentaoep`.`zt_task`.`parent` >= '0'), `zentaoep`.`zt_task`.`estimate`, 0)) AS `estimate`,
       sum(if((`zentaoep`.`zt_task`.`parent` >= '0'), `zentaoep`.`zt_task`.`consumed`, 0)) AS `consumed`,
       sum(if(((`zentaoep`.`zt_task`.`status` <> 'cancel') and (`zentaoep`.`zt_task`.`status` <> 'closed') and
               (`zentaoep`.`zt_task`.`parent` >= '0')), `zentaoep`.`zt_task`.`left`, 0)) AS   `left`,
       count(0) AS                                                                            `number`,
       sum(if(((`zentaoep`.`zt_task`.`status` = 'wait') or (`zentaoep`.`zt_task`.`status` = 'doing')), 1,
              0)) AS                                                                          `undone`,
       sum((`zentaoep`.`zt_task`.`consumed` + if(
               ((`zentaoep`.`zt_task`.`status` <> 'cancel') and (`zentaoep`.`zt_task`.`status` <> 'closed') and
                (`zentaoep`.`zt_task`.`parent` >= '0')), `zentaoep`.`zt_task`.`left`, 0))) AS `totalReal`
from `zentaoep`.`zt_task`
where (`zentaoep`.`zt_task`.`deleted` = '0')
group by `zentaoep`.`zt_task`.`project`;

