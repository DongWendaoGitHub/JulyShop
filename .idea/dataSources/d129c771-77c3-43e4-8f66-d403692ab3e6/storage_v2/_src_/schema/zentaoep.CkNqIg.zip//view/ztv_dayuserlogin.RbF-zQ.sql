create view ztv_dayuserlogin as
select count(0) AS `userlogin`, left(`zentaoep`.`zt_action`.`date`, 10) AS `day`
from `zentaoep`.`zt_action`
where ((`zentaoep`.`zt_action`.`objectType` = 'user') and (`zentaoep`.`zt_action`.`action` = 'login'))
group by left(`zentaoep`.`zt_action`.`date`, 10);

